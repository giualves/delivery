package com.utfpr.delivery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.utfpr.delivery.entity.Restaurante;
import com.utfpr.delivery.service.RestauranteService;

@RestController
@RequestMapping("/restaurantes")
public class RestauranteController {
	
	@Autowired
	private RestauranteService restauranteService;
	
	@GetMapping
	@ResponseBody
	public List<Restaurante> listarTodosOsRestaurantes() {
		
		return restauranteService.listarTodosOsRestaurantes();
		
	}
	
	@GetMapping("/{id}")
	@ResponseBody
	public Restaurante getRestauranteById(@PathVariable Long id) {
		
		return restauranteService.getRestauranteById(id);
		
	}
	
	@PostMapping
	@ResponseStatus(code = HttpStatus.CREATED)
	private Restaurante adicionar(@RequestBody Restaurante restaurante) {
		
		return restauranteService.salvar(restaurante);
		
	}

}

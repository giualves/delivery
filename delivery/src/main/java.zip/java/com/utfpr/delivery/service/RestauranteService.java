package com.utfpr.delivery.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.utfpr.delivery.entity.Restaurante;
import com.utfpr.delivery.repository.RestauranteRepository;

@Service
public class RestauranteService {
	
	@Autowired
	private RestauranteRepository restauranteRepository;
	
	public List<Restaurante> listarTodosOsRestaurantes() {
		
		return restauranteRepository.findAll();
		
	}
	
	public Restaurante getRestauranteById(Long id) {
		
		Optional<Restaurante> restaurante = restauranteRepository.findById(id);
		
		if (restaurante.isPresent()) {
			return restaurante.get();
		}
		
		return null;
		
	}
	
	public Restaurante salvar(Restaurante restaurante) {
		
		return restauranteRepository.save(restaurante);
		
	}
	
}
